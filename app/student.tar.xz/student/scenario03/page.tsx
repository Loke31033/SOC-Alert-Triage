"use client";

import { useEffect, useState } from "react";

type Question = {
  question_id: string;
  question_type: string;
  question: string;
  options: Record<string, string>;
  marks: number;
};

type QuestionPackage = {
  package_type: string;
  team_id: string;
  scenario_id: string;
  scenario_name: string;
  total_questions: number;
  total_marks: number;
  questions: Question[];
};

type EvaluationResult = {
  score: number;
  total_marks: number;
  percentage: number;
};

export default function Scenario03Page() {
  const [data, setData] = useState<QuestionPackage | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<EvaluationResult | null>(null);

  useEffect(() => {
    async function loadQuestions() {
      try {
        const response = await fetch(
          `/api/student/scenario03?team_id=${sessionStorage.getItem("student_team_id") || ""}`,
          {
            cache: "no-store",
          }
        );

        if (!response.ok) {
          throw new Error("Unable to load scenario questions.");
        }

        const json: QuestionPackage = await response.json();

        setData(json);
      } catch (err) {
        console.error(err);
        setError("Failed to load SCENARIO 03 questions.");
      } finally {
        setLoading(false);
      }
    }

    loadQuestions();
  }, []);

  function handleAnswer(
    questionId: string,
    option: string
  ) {
    if (submitted) {
      return;
    }

    setAnswers((previous) => ({
      ...previous,
      [questionId]: option,
    }));
  }

  async function handleSubmit() {
    if (!data || submitting || submitted) {
      return;
    }

    const answeredCount = Object.keys(answers).length;

    if (answeredCount !== data.total_questions) {
      alert(
        `Please answer all ${data.total_questions} questions before submitting.`
      );

      return;
    }

    setSubmitting(true);
    setError("");

    try {
      const submission = {
        submission_type: "student_mcq_submission",
        submission_mode: "web",

        team_id: data.team_id,

        scenario_id: data.scenario_id,

        answers: data.questions.map((question) => ({
          question_id: question.question_id,
          answer: answers[question.question_id],
        })),
      };

      console.log(
        "Submitting to contest evaluator:",
        submission
      );

      const response = await fetch(
        "/api/student/submit",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify(submission),
        }
      );

      const evaluation = await response.json();

      console.log(
        "Evaluator response:",
        evaluation
      );

      if (!response.ok || !evaluation.success) {
        throw new Error(
          evaluation.error ||
          "Submission evaluation failed."
        );
      }

      setResult({
        score: evaluation.score,
        total_marks: evaluation.total_marks,
        percentage: evaluation.percentage,
      });

      setSubmitted(true);

    } catch (err) {
      console.error(err);

      setError(
        err instanceof Error
          ? err.message
          : "Submission failed."
      );

    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
        <p className="text-lg">
          Loading SCENARIO 03...
        </p>
      </main>
    );
  }

  if (error && !data) {
    return (
      <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <div className="bg-red-950 border border-red-700 rounded-xl p-8">
          <h1 className="text-xl font-bold mb-2">
            Error
          </h1>

          <p>
            {error}
          </p>
        </div>
      </main>
    );
  }

  if (!data) {
    return null;
  }

  if (submitted && result) {
    return (
      <main className="min-h-screen bg-slate-950 text-white p-6 md:p-10">

        <div className="max-w-3xl mx-auto">

          <div className="bg-slate-900 border border-green-700 rounded-2xl p-8 text-center">

            <div className="text-green-400 text-5xl mb-4">
              ✓
            </div>

            <h1 className="text-3xl font-bold mb-3">
              Submission Evaluated
            </h1>

            <p className="text-slate-300 mb-8">
              Your SCENARIO 03 investigation has been
              evaluated successfully.
            </p>

            <div className="grid md:grid-cols-3 gap-4 mb-8">

              <div className="bg-slate-800 rounded-xl p-5">
                <p className="text-slate-400 text-sm">
                  Team
                </p>

                <p className="text-xl font-bold mt-2">
                  {data.team_id}
                </p>
              </div>

              <div className="bg-slate-800 rounded-xl p-5">
                <p className="text-slate-400 text-sm">
                  Score
                </p>

                <p className="text-3xl font-bold text-green-400 mt-2">
                  {result.score}/{result.total_marks}
                </p>
              </div>

              <div className="bg-slate-800 rounded-xl p-5">
                <p className="text-slate-400 text-sm">
                  Percentage
                </p>

                <p className="text-3xl font-bold text-blue-400 mt-2">
                  {result.percentage}%
                </p>
              </div>

            </div>

            <div className="bg-slate-800 rounded-xl p-5 text-left">

              <p className="text-slate-400">
                Scenario
              </p>

              <p className="font-semibold mt-1">
                {data.scenario_id.toUpperCase()}
              </p>

              <p className="text-slate-400 mt-4">
                Questions Submitted
              </p>

              <p className="font-semibold mt-1">
                {data.total_questions}/{data.total_questions}
              </p>

            </div>

            <p className="text-green-400 text-sm mt-6">
              Score generated by the official contest evaluator.
            </p>

          </div>

        </div>

      </main>
    );
  }

  const answeredCount =
    Object.keys(answers).length;

  return (
    <main className="min-h-screen bg-slate-950 text-white p-6 md:p-10">

      <div className="max-w-5xl mx-auto">

        {/* HEADER */}

        <header className="mb-8">

          <p className="text-blue-400 font-semibold mb-2">
            SOC ALERT TRIAGE CONTEST
          </p>

          <h1 className="text-3xl md:text-4xl font-bold">
            {data.scenario_id.toUpperCase()} —{" "}
            {data.scenario_name}
          </h1>

          <div className="flex flex-wrap gap-4 mt-4 text-sm text-slate-400">

            <span>
              Team: {data.team_id}
            </span>

            <span>
              Questions: {data.total_questions}
            </span>

            <span>
              Marks: {data.total_marks}
            </span>

          </div>

        </header>


        {/* INVESTIGATION INSTRUCTIONS */}

        <section className="bg-slate-900 border border-slate-700 rounded-xl p-6 mb-8">

          <h2 className="text-xl font-bold mb-4">
            Investigation Instructions
          </h2>

          <div className="text-slate-300 space-y-2">

            <p>
              Investigate the assigned scenario using
              your team-specific Kibana environment.
            </p>

            <p>
              Analyze the available events and identify
              the activity relevant to the investigation
              questions.
            </p>

            <p>
              Submit your answers only after completing
              your investigation.
            </p>

          </div>

          <button
            type="button"
            onClick={() => {
              (() => {
                const storedTeamId =
                  sessionStorage.getItem("student_team_id");

                const storedScenarioId =
                  data?.scenario_id || "scenario01";

                if (!storedTeamId) {
                  throw new Error(
                    "Student team identity is missing. Please login again."
                  );
                }

                const params = new URLSearchParams({
                  team_id: storedTeamId,
                  scenario_id: storedScenarioId,
                });

                return fetch(
                  `/api/student/kibana?${params.toString()}`,
                  {
                    method: "GET",
                    cache: "no-store",
                  }
                );
              })()
                .then(async (response) => {
                  const json = await response.json();

                  if (!response.ok || !json.success || !json.kibana_url) {
                    throw new Error(
                      json.error || "Unable to create Kibana access."
                    );
                  }

                  window.open(
                    json.kibana_url,
                    "_blank",
                    "noopener,noreferrer"
                  );
                })
                .catch((err) => {
                  console.error(err);
                  setError(
                    err instanceof Error
                      ? err.message
                      : "Unable to open Kibana."
                  );
                });
            }}
            className="mt-6 bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-semibold"
          >
            Open Kibana
          </button>

        </section>


        {/* ERROR */}

        {error && (
          <div className="bg-red-950 border border-red-700 text-red-200 rounded-xl p-4 mb-8">
            {error}
          </div>
        )}


        {/* PROGRESS */}

        <section className="bg-slate-900 border border-slate-700 rounded-xl p-5 mb-8">

          <div className="flex justify-between mb-2">

            <span className="font-semibold">
              Answer Progress
            </span>

            <span className="text-slate-400">
              {answeredCount} / {data.total_questions}
            </span>

          </div>

          <div className="w-full bg-slate-800 rounded-full h-3">

            <div
              className="bg-blue-600 h-3 rounded-full transition-all"
              style={{
                width: `${
                  (answeredCount /
                    data.total_questions) *
                  100
                }%`,
              }}
            />

          </div>

        </section>


        {/* QUESTIONS */}

        <section className="space-y-6">

          {data.questions.map(
            (question, index) => (

              <article
                key={question.question_id}
                className="bg-slate-900 border border-slate-700 rounded-xl p-6"
              >

                <div className="flex justify-between gap-4 mb-5">

                  <h2 className="text-lg font-semibold">
                    Q{index + 1}.{" "}
                    {question.question}
                  </h2>

                  <span className="text-sm text-blue-400 whitespace-nowrap">
                    {question.marks} marks
                  </span>

                </div>

                <div className="space-y-3">

                  {Object.entries(
                    question.options
                  ).map(
                    ([letter, value]) => {

                      const selected =
                        answers[
                          question.question_id
                        ] === letter;

                      return (
                        <button
                          key={letter}
                          type="button"
                          onClick={() =>
                            handleAnswer(
                              question.question_id,
                              letter
                            )
                          }
                          className={`w-full text-left p-4 rounded-lg border transition ${
                            selected
                              ? "border-blue-500 bg-blue-950"
                              : "border-slate-700 bg-slate-800 hover:border-slate-500"
                          }`}
                        >

                          <span className="font-bold mr-3">
                            {letter}.
                          </span>

                          {value}

                        </button>
                      );
                    }
                  )}

                </div>

              </article>

            )
          )}

        </section>


        {/* SUBMIT */}

        <section className="mt-10 bg-slate-900 border border-slate-700 rounded-xl p-6">

          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5">

            <div>

              <h2 className="text-xl font-bold">
                Submit Investigation
              </h2>

              <p className="text-slate-400 mt-1">
                {answeredCount} of{" "}
                {data.total_questions} questions answered.
              </p>

            </div>

            <button
              type="button"
              disabled={
                submitting ||
                answeredCount !==
                  data.total_questions
              }
              onClick={handleSubmit}
              className={`px-8 py-4 rounded-lg font-bold ${
                submitting ||
                answeredCount !==
                  data.total_questions
                  ? "bg-slate-700 text-slate-400 cursor-not-allowed"
                  : "bg-green-600 hover:bg-green-700 text-white"
              }`}
            >

              {submitting
                ? "Evaluating..."
                : "Submit Answers"}

            </button>

          </div>

        </section>

      </div>

    </main>
  );
}
